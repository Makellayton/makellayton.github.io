// Minimal interactivity + project loader
document.getElementById('year').textContent = new Date().getFullYear();

async function loadProjects(){
  try{
    const res = await fetch('assets/projects.json');
    const data = await res.json();
    const grid = document.getElementById('project-grid');
    data.forEach(p => {
      const card = document.createElement('article');
      card.className = 'card';
      card.innerHTML = `
        <img src="${p.image}" alt="${p.title}">
        <div class="card-body">
          <h3>${p.title}</h3>
          <p>${p.summary}</p>
          <div class="tags">
            ${p.tags.map(t=>`<span class="tag">${t}</span>`).join('')}
          </div>
          <div class="cta">
            ${p.github ? `<a class="btn btn-ghost" href="${p.github}" target="_blank" rel="noopener">GitHub</a>`:''}
            ${p.caseStudy ? `<a class="btn" href="${p.caseStudy}" target="_blank" rel="noopener">View Project</a>`:''}
          </div>
        </div>`;
      grid.appendChild(card);
    });
  }catch(e){
    console.error('project load failed', e);
  }
}
loadProjects();
